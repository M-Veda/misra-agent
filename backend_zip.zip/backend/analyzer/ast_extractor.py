﻿from analyzer.analysis_context import AnalysisContext
from analyzer.ast_visitor import ASTVisitor
from analyzer.cfg_builder import CFGBuilder
from analyzer.clang_parser import ClangParser
from analyzer.symbol_table import SymbolTableBuilder
from analyzer.type_analyzer import TypeAnalyzer


class ASTExtractor:
    def __init__(self):
        self.parser = ClangParser()
        self.symbol_builder = SymbolTableBuilder()
        self.type_analyzer = TypeAnalyzer()
        self.cfg_builder = CFGBuilder()

    def extract(self, file_path):
        try:
            parsed = self.parser.parse(file_path)
            return self._build_context(
                file_path=file_path,
                source_code=parsed.get("source", ""),
                parsed=parsed,
                available=True,
            )
        except Exception as exc:
            return AnalysisContext(
                file_path=file_path,
                source_code="",
                available=False,
                parse_error=str(exc),
                visitor=ASTVisitor(),
            )

    def extract_from_source(self, source_code):
        return self._build_context(
            file_path="<memory>",
            source_code=source_code,
            parsed={"source": source_code},
            available=True,
        )

    def _build_context(self, file_path, source_code, parsed=None, available=True, parse_error=None):
        visitor = ASTVisitor(ast=parsed)
        visitor.visit(parsed)
        context = AnalysisContext(
            file_path=file_path,
            source_code=source_code,
            available=available,
            ast=parsed,
            visitor=visitor,
            parse_error=parse_error,
            declarations=getattr(visitor, "declarations", []),
        )
        context.symbol_table = self.symbol_builder.build(context)
        context.type_information = self.type_analyzer.analyze(context)
        context.cfg = self.cfg_builder.build(context)
        return context
